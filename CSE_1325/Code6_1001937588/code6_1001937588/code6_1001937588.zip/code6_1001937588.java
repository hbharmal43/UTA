/**
Name: Hasnain Bharmal
ID:1001937588
 */
package code6_1001937588;

import javax.swing.JFrame;

public class code6_1001937588 
{

    public static void main(String[] args) 
    {
        Password password = new Password();
        password.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        password.setSize(460,200);
        password.setVisible(true);

    }
} 